<?php

$band = "NEW PRODUCT: To grow better, you need to run better. Check out our newest product, Operations Hub, and experience operations reimagined.";

$jumbo = ['There’s a better way to grow.',
          'Marketing, sales, and service software that helps your business grow without compromise. Because "good for the business” should also mean “good for the customer".',
          'Get Hubspot Free',
          'Get started with FREE tools, and upgrade as you grow.']

?>
<div class="jumbotron">

    <div class="band">
        <div class="container pippo">
            <div class="band-left">
                <?php echo e(__($band)); ?>

            </div>

            <div class="band-right">
                <?php echo e(__("Explore Operations Hub")); ?>

            </div>
        </div>
    </div>

    <div class="jumbotroncontainer">
        <div class="container jumbo-txt">
            <ul>
                <?php $__currentLoopData = $jumbo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($listitem); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
        </div>
    </div>


    
    <?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="display-4 text-center" style="font-size: 3.0rem"><?php echo e(__('lang.welcome')); ?></h1>
        <h3 class="display-4 text-center" style="font-size: 2.0rem"><?php echo e(__('lang.title')); ?></h3>
        <h4 class="display-4 text-center" style="font-size: 1.5rem"><?php echo e(__("lang.title2")); ?></h4>

        <h4 class="display-4 text-center" style="font-size: 1.5rem"><?php echo e(__("Let's learn localization with Laravel")); ?></h4>
        <h4 class="display-4 text-center" style="font-size: 4.5rem"><?php echo e(__("Dio serpente avvelenato")); ?></h4>
        <br><br>
    </div>
    <?php $__env->stopSection(); ?>

</div>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/work/Desktop/test-laravel/resources/views/jumbotron.blade.php ENDPATH**/ ?>