<?php
$imgsecthree = [
    'https://f.hubspotusercontent00.net/hubfs/53/1200px-WWF_logo_svg%20(1).png',
    'https://f.hubspotusercontent00.net/hubfs/53/trello-logo-blue%20(1).png',
    'https://f.hubspotusercontent00.net/hubfs/53/1200px-G2_Crowd_logo.svg.png',
    'https://www.hubspot.com/hubfs/assets/hubspot.com/homepage/Vertical_Sabaeus_RGB.svg',
    'https://newinboundblog.hubspot.com/hubfs/assets/hubspot.com/case-studies/logo-bank/EMEA-logo-bank/Suzuki.png',
    'https://f.hubspotusercontent00.net/hubfs/53/soundcloud.png',
    'https://www.hubspot.com/hubfs/assets/hubspot.com/home/home_page_logos_June_2019/Classpass-logo@2x.png',
    'https://www.hubspot.com/hubfs/assets/hubspot.com/home/home_page_logos_June_2019/VMware_logo_gry_RGB_300dpi@2x.png'
];

$number = '100,000+';
$numbertxt = 'customers in over 120 countries growing their businesses with HubSpot';


$secthreeimg = 'https://cdn2.hubspot.net/hubfs/53/assets/hubspot.com/_style-guide/sg-module-images/12@2x.png';
$secthreetitle = 'Start Growing With HubSpot Today';
$secthreetxt = 'With tools to make every part of your process more human and a support team excited to help you, getting started with inbound has never been easier.';
$freemium = 'Get started with FREE tools, or get more with our premium software.';
$btnsecthree = 'Get HubSpot free';
?>


<div class="sec-three">
    <div class="section-top">
        <div class="top-left">
            <h2><?php echo e(__($number)); ?></h2>
            <p class="p-top"><?php echo e(__($numbertxt)); ?></p>
        </div>
        <div class="top-right">
            
            
            <div class="img-container">
                <img src="https://f.hubspotusercontent00.net/hubfs/53/1200px-WWF_logo_svg%20(1).png" alt="">
                <img src="https://f.hubspotusercontent00.net/hubfs/53/trello-logo-blue%20(1).png" alt="">
                <img src="https://f.hubspotusercontent00.net/hubfs/53/1200px-G2_Crowd_logo.svg.png" alt="">
                <img src="https://www.hubspot.com/hubfs/assets/hubspot.com/homepage/Vertical_Sabaeus_RGB.svg" alt="">
                <img src="https://newinboundblog.hubspot.com/hubfs/assets/hubspot.com/case-studies/logo-bank/EMEA-logo-bank/Suzuki.png" alt="">
                <img src="https://f.hubspotusercontent00.net/hubfs/53/soundcloud.png" alt="">
                <img src="https://www.hubspot.com/hubfs/assets/hubspot.com/home/home_page_logos_June_2019/Classpass-logo@2x.png" alt="">
                <img src="https://www.hubspot.com/hubfs/assets/hubspot.com/home/home_page_logos_June_2019/VMware_logo_gry_RGB_300dpi@2x.png" alt="">
            </div>
        </div>
    </div>


    <div class="section-bottom">

        <div class="bottom-left">
            <h3><?php echo e(__($secthreetitle)); ?></h3>
            <p class="p-bottom"><?php echo e(__($secthreetxt)); ?></p>
            <div class="btn"><?php echo e(__($btnsecthree)); ?></div>
            <small><?php echo e(__($freemium)); ?></small>
        </div>

        <div class="bottom-right">
            <img class="chick" src="<?php echo e($secthreeimg); ?>" alt="">
        </div>
      
    </div>
</div><?php /**PATH /Users/work/Desktop/hubspot-localised/resources/views/sectionthree.blade.php ENDPATH**/ ?>