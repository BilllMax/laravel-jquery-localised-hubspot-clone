<?php
$navhamburger = [
    'Software',
    'Pricing',
    'Resources',
    'About'
];

$burgerbtn = 'Get HubSpot free';

$logo = 'https://cdn3.iconfinder.com/data/icons/logos-and-brands-adobe/512/168_Hubspot-512.png';

$burgerdown = '[
    {
        "icon":"language",
        "txt":"English",
        "icontwo":"arrow_drop_down"
    },
    {
        "icon":"account_circle",
        "txt":"Contact Sales",
        "icontwo":""
    },
    {
        "icon":"",
        "txt":"Go to my account",
        "icontwo":""
    },
    {
        "icon":"",
        "txt":"Customer Support",
        "icontwo":""
    }
   ]';

   $arraydown = json_decode($burgerdown, true);
?>




<div class="hamburger">
    <div class="hamburger-container">
        <div class="nav">
            <img src="<?php echo e(__($logo)); ?>" alt="">
            <input type="search" placeholder="Search HubSpot.com">
            <span class="material-icons x-toggle">
                close
            </span>
        </div>

        <?php $__currentLoopData = $navhamburger; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="rectangle">
            <div><?php echo e(__($item)); ?></div>
            <span class="material-icons">
                keyboard_arrow_right
            </span>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="btn-hamburger">
            <?php echo e(__($burgerbtn)); ?>

        </div>

        <div class="bottom-burger">
            <?php $__currentLoopData = $arraydown; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bottom-burger-inside">
                <span class="material-icons"><?php echo e($item['icon']); ?></span>
                <div><?php echo e(__($item['txt'])); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>
<?php /**PATH /Users/work/Desktop/prova/resources/views/hamburger.blade.php ENDPATH**/ ?>