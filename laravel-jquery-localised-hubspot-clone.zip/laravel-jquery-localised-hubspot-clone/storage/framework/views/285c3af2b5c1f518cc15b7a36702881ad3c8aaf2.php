<html>
<body>
    <div id="app">
        <div style="background-color: #343a40;">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark container">
                <div class="collapse navbar-collapse" id="navbarToggler">
                    <ul class="navbar-nav ml-auto">
                        <?php $locale = session()->get('locale'); ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                               data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php switch($locale):
                                    case ('us'): ?>
                                    <img src="<?php echo e(asset('img/us.png')); ?>"> English
                                    <?php break; ?>
                                    <?php case ('de'): ?>
                                    <img src="<?php echo e(asset('img/de.png')); ?>"> German
                                    <?php break; ?>
                                    <?php case ('in'): ?>
                                    <img src="<?php echo e(asset('img/in.png')); ?>"> Hindi
                                    <?php break; ?>
                                    <?php case ('fr'): ?>
                                    <img src="<?php echo e(asset('img/fr.png')); ?>"> French
                                    <?php break; ?>
                                    <?php case ('es'): ?>
                                    <img src="<?php echo e(asset('img/es.png')); ?>"> Spanish
                                    <?php break; ?>
                                    <?php case ('ch'): ?>
                                    <img src="<?php echo e(asset('img/ch.png')); ?>"> Chinese
                                    <?php break; ?>
                                    <?php default: ?>
                                    <img src="<?php echo e(asset('img/us.png')); ?>"> English
                                <?php endswitch; ?>
                                <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="/en"><img src="<?php echo e(asset('img/us.png')); ?>"> English</a>
                                <a class="dropdown-item" href="/de"><img src="<?php echo e(asset('img/de.png')); ?>"> German</a>
                                <a class="dropdown-item" href="/in"><img src="<?php echo e(asset('img/in.png')); ?>"> Hindi</a>
                                <a class="dropdown-item" href="/fr"><img src="<?php echo e(asset('img/fr.png')); ?>"> French</a>
                                <a class="dropdown-item" href="/es"><img src="<?php echo e(asset('img/es.png')); ?>"> Spanish</a>
                                <a class="dropdown-item" href="/ch"><img src="<?php echo e(asset('img/ch.png')); ?>"> Chinese</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>  
    </body>
    </html><?php /**PATH /Users/work/Desktop/prova/resources/views/layout.blade.php ENDPATH**/ ?>